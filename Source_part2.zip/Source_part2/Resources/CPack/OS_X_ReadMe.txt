In order to save space and download time the DREAM.3D OS X distribution uses a
shared Frameworks and Library folder. Because of this if you want to move the
DREAM.3D applications you MUST move the entire DREAM.3D Distribution folder and
NOT individual applications and utilities.

Thanks
The DREAM3D Dev Team.