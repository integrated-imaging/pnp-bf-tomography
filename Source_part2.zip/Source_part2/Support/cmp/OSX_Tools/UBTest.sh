#!/bin/bash
#echo "Running $1 architecture of $2 test"
arch -arch $1 $2
