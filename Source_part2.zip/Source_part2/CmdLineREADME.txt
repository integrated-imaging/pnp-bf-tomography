Code for Bright Field electron tomographic reconstruction  

This package contains source codes to reconstruct Bright-Field
tomographic data using the 
Model Based Iterative Reconstruction method. The source codes are open source
under a BSD License. See the License.txt file for more information.

The current set of dependencies are:

Boost version 1.44 or newer
Qt version 4.7.4 or newer
libTiff
TBB

In order to build the sources you will also need the following:

CMake version 2.8.6 or newer.

The codes are known to compile on OS X (10.6, 10.7, 10.8), Windows (Visual Studio 2008 and 2010)
and RedHat Enterprise Linux 5.x, CentOS 5.x and OpenSUSE 12.1

*****************************************
To compile code on Unix based OS: 
*****************************************

1) cd to the Source/ folder

2) mkdir Build 

3) cd Build 

4) ccmake ../ (Using this to create the appropriate type of project. 
Can create Makefile or XCode or MS Visual studio style "projects")
 
If you wish to adjust the parameters, switch off flags like GUI 

5) make 

*********************************
Running the command line code 
*********************************

Note : All arguments within a [] are optional parameters.The <> indicate the default values of the parameters.

./MbirReconstruction  -s <> : Full path of the aligned input MRC file. Expects the mrc header to be in the FEI format to read tilt 
                              angles and pixel size
                     --subvolume : Sub-volume to choose of the form x_start,y_start,tilt_start,x_end,y_end,tilt_end
                                   The code assumes the data is centered i.e. the center of rot is at (x_end-x_start)/2
                      --outputfile : Full path of the output .rec/mrc file
                      --thickness : Sample thickness in nano-meters 
                      --sigma_x  : The scaling parameter in the q-GGMRF prior in units of nm^{-1}. (The GUI tool has an 
     automatic algorithm estimating this)
                      --default_dosage :  The dosage value in counts when the material is not present
                      --use_default_dosage    :  A flag to tell the code to use the default input dosage value. Must be used. 
 
                      [--diffuseness <0.2>]  : The value used to compute the prior model parameter "p" (p = diffuseness + 1)
                      [--bragg_T <3>]   : Forward model Bragg threshold parameter  
                      [--bragg_delta <0.5>]  : Forward model Bragg delta (weighting) parameter 
                      [--default_variance]    : The scaling value for the variance (\sigma^{2} in the paper)                      
                      [--bf_offset <0>]        : Offset in the measured counts. This value is added to the input file (Note: 
                                                 For several real data sets this HAS TO BE SET to 32768)
                      [--tilt_selection <0>] : Which was the tilt axis : 0 is default (y-axis)                    
                      
                      [--final_resolution <1>] : The resolution of the reconstructed pixels in integer multiples 
                                                of the detector size 
                      [--stop_threshold <.001>] : Stopping criteria as a percentage change of voxels relative 
                                                  to the previous iteration
                      [--num_resolutions <3> ]  : Number of resolutions of the multi-resolution reconstruction
                      [ --outer_iterations <600>] : Maximum number of outer non-homogenous subiterations
                      [ --inner_iterations <100>] : Maximum number of inner non-homogenous subiterations 
                                                    at the coarsest resolution. 
                                                    This is done to provide a reasonable initial condition to the algo 
                      [--default_recon_value <0>] : At the coarsest resolution the object is initialized to this value
                      [--extend_object]       : Typical microscope samples extend out on the sides. An accurate 
                                                reconstruction requires using this flag to reconstruct 
                                                a large volume
                      [--delete_tmp_files]   : This flag is used to clear the temporary files created
                      [--exclude_views]      : Used to exclude certain views. Indicate the views to exclude 
                                               separated by "," (Ex: --exclude_views 5,10,30)

* Running the GUI 

   Requires Qt and cmake to correctly point to the GUI software. 
   Go throug same steps as before. 
   After "make"
   cd Bin/
   open the TEMBIR.app
