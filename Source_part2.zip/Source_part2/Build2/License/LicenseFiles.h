#ifndef _LICENSE_FILES_H_
#define _LICENSE_FILES_H_
namespace OpenMBIR {
  QStringList LicenseList = (QStringList()   << ":/License.txt" << ":/Boost.license" << ":/MXA.license" << ":/Qt.license" << ":/tiff.license");
}
#endif /* _LICENSE_FILES_H_ */ 
