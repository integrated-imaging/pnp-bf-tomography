Part of this code was written under United States Air Force Contract FA8650-07-D-5800

Other parts of the code were written under other contracts or provided by open source
projects. See the License.txt file for more information.

All source code has been release under US Air Force Public Affairs Case number 88ABW-2011-1237

