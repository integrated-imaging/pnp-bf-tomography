#!/bin/sh
make -C /Users/suhas/Documents/Research/Code/Mine/BfMbir_v1/Source/Build2 -f /Users/suhas/Documents/Research/Code/Mine/BfMbir_v1/Source/Build2/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
