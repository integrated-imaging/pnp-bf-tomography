#!/bin/sh
make -C /Users/suhas/Documents/Research/Code/Mine/BfMbir_v1/Source/Build2 -f /Users/suhas/Documents/Research/Code/Mine/BfMbir_v1/Source/Build2/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
