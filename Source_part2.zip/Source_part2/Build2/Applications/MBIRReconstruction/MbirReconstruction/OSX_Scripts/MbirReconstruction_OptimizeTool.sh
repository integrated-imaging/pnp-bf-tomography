#! /bin/bash
# This script requires a single argument which is the current install path

DEBUG=0
# -----------------------------------------------------------------------------
#  Conditional Printing
# -----------------------------------------------------------------------------
function printStatus()
{
	if [ "x$DEBUG" = "x1" ]; then
	    echo "${1}"
	fi	
}



InstallPrefix="${1}"
PackageInstallDest="${1}"
printStatus "CMAKE_INSTALL_PREFIX: ${InstallPrefix}"
ProjectBinaryDir=tools
ApplicationName="MbirReconstruction"
ApplicationExe="${InstallPrefix}/${ProjectBinaryDir}/${ApplicationName}"

LibDirName="lib"
LibPath="${InstallPrefix}/${LibDirName}"
InstallNameLib="@executable_path/../${LibDirName}"
FrameworkDirName="Frameworks"
FrameworkPath="${ApplicationBundleName}/Contents/${FrameworkDirName}"
InstallNameFramework="@executable_path/../${FrameworkDirName}"
PluginDirName="Plugins"
PluginPath="${ApplicationBundleName}/Contents/${PluginDirName}"
InstallNamePlugin="@executable_path/../${PluginDirName}"
ResourcesDirName="Resources"
ResourcesPath="${ApplicationBundleName}/Contents/${ResourcesDirName}"

BuildDir="/Users/suhas/Documents/Research/Code/Mine/BfMbir_v1/Source/Build2/Bin"


TmpDir="/tmp"

#-------------------------------------------------------------------------------
# List of Bundled Libraries to copy and correct. This list is a comma seperated
# list of libraries. Each Library NEEDS to be in the form of an absolute path.
BUNDLE_LIBRARIES=""

# -----------------------------------------------------------------------------
#  Copy the .app bundle to the installation location so we can
# work with it there.
printStatus "Removing Previous Installation at ${ApplicationExe}"
rm -rf "${ApplicationExe}"

printStatus "Copying  ${BuildDir}/${ApplicationName} to ${InstallPrefix}/${ProjectBinaryDir}/"
mkdir -p "${InstallPrefix}/${ProjectBinaryDir}/"
cp "${BuildDir}/${ApplicationName}" "${InstallPrefix}/${ProjectBinaryDir}/."

#-- Be sure the Resources, lib, frameworks and plugins directories are created
mkdir -p "${LibPath}"

# -----------------------------------------------------------------------------
# Put each Library on its own line, thus preserving spaces in the filename
# Pipe the output into the read command to process each line
# The variable 'line' now contains the absolute path to a library
#echo ${BUNDLE_LIBRARIES} | tr ";" "\012" | while read line
#do
#    
#done


# -----------------------------------------------------------------------------
#  $1 is the path to a framework
#  $2 is the target file to update
# -----------------------------------------------------------------------------
function CorrectLinkedFrameworkInstallName()
{
	printStatus "      |-  CorrectLinkedFrameworkInstallName"
	printStatus "          |- 1: ${1}"
    printStatus "          |- 2: ${2}"
    oldPath="${1}"
    libName=`basename ${oldPath}`
    frameworkName="${libName}.framework"
    frameworkRootDir="${1%${frameworkName}*}"
    frameworkBundle="${frameworkRootDir}${frameworkName}"
	newPath="${InstallNameFramework}/${1#${frameworkRootDir}*}" 
	printStatus "          |- oldPath: ${oldPath}"
	printStatus "          |- newPath: ${newPath}"
	install_name_tool -change ${oldPath} ${newPath} ${2}
}

# -----------------------------------------------------------------------------
#  uses install_name_tool to correct all the DEPENDENCIES of an input file
#  $1 is an install_name to check. This was generated from a call to otool -L
#  $2 is the Library in its final installed location
# -----------------------------------------------------------------------------
function CorrectLibraryDependency()
{
  pattern=" \(*\)"            # everything between '(' and ')'
  oldPath="${1%$pattern}"
  # Filter out System Libraries or those located in /Libary/Frameworks
  isSystem=`expr  "${oldPath}" : '/System'`
  isUsrLib=`expr "${oldPath}" : '/usr/lib'`
  #isLibFrwk=`expr "${oldPath}" : '/Libraray/Frameworks'`
  isEmbeddedPathExe=`expr "${oldPath}" : '@executable_path/'`
  isEmbeddedPathLdr=`expr "${oldPath}" : '@loader_path/'`
  if [[ "$isSystem" = "0" \
    && "$isUsrLib" = "0" \
    && "$isEmbeddedPathExe" = "0" \
    && "$isEmbeddedPathLdr" = "0" ]]; then
      printStatus "    |-  CorrectLibraryDependency"
      printStatus "      |-  ${1}"
      printStatus "      |-  ${2}"
      libName=`basename ${oldPath}`
      frameworkName="${libName}.framework"
      isFramework=` echo ${oldPath} | grep "${frameworkName}"`
      if [[ "${#isFramework}" = "0" ]]; then
      	libName=`basename ${oldPath}`
        newPath="${InstallNameLib}/${libName}"
        install_name_tool -change "${oldPath}" "${newPath}" "${2}"
      else
        CorrectLinkedFrameworkInstallName "${oldPath}" "${2}"
      fi
   fi
}

# -----------------------------------------------------------------------------
#  uses install_name_tool to correct this library's dependencies
#  $1 is a linked library to update
# -----------------------------------------------------------------------------
function UpdateLibraryDependencies()
{
	  printStatus "    |- UpdateLibraryDependencies ${1}"
	  local libFile
	  local libOutFile
	  local i
	  
	  libFile="${1}"
	  libOutFile="${TmpDir}/otool-library.out"
	  otool -L "${1}" > "${libOutFile}"
	  i=0
	  exec 10<"${libOutFile}"
	  while read -u 10 line
	    do
	    if [[ ${i} -gt 1 ]]; then
	        CorrectLibraryDependency "${line}" "${1}"
	        let i=i+1
	    fi
	    let i=i+1
	  done
	  exec 10<&-
}

# -----------------------------------------------------------------------------
#  uses install_name_tool to correct this framework
#  $1 is a linked framework
#  $2 is the executable
# -----------------------------------------------------------------------------
function UpdateFrameworkInstallName()
{
    printStatus "  |- UpdateFrameworkInstallName"
    printStatus "     |  ${1}"
    printStatus "     |  ${2}"
    local frameworkBundle
    local frameworkName
    local frameworkRootDir
    local libName
    if [[ -e ${1} ]]; then
        #-- Copy the Framework using the current "install_name" as the path
        printStatus "     |  Copying Framework '${1}' into app bundle"
        
        libName=`basename ${1}`
        frameworkName="${libName}.framework"
        frameworkRootDir="${1%${frameworkName}*}"
        frameworkBundle="${frameworkRootDir}${frameworkName}"
        printStatus "     |  frameworkRootDir: ${frameworkRootDir}"
        printStatus "     |  frameworkBundle: ${frameworkBundle}"

        cp -R "${frameworkBundle}" "${PackageInstallDest}/bin/${FrameworkPath}/."
        
        # Update the Executables link path to this library
        oldPath="${1}"
        libName=`basename ${oldPath}`
        newPath="${InstallNameFramework}/${1#${frameworkRootDir}*}" 
        printStatus "     | oldPath: ${oldPath}"
        printStatus "     | newPath: ${newPath}"
        printStatus "     | 2: ${2}"
        install_name_tool -change ${oldPath} ${newPath} ${2}
        
        # Update the install_name of the library itself
        install_name_tool -id ${newPath} "${PackageInstallDest}/bin/${FrameworkPath}/${1#${frameworkRootDir}*}"
        
        UpdateLibraryDependencies "${PackageInstallDest}/bin/${FrameworkPath}/${1#${frameworkRootDir}*}"

    fi
}

# -----------------------------------------------------------------------------
#  uses install_name_tool to correct this library
#  $1 is a linked library
#  $2 is the executable
# -----------------------------------------------------------------------------
function UpdateDylibInstallName()
{
	printStatus "  |- UpdateDylibInstallName"
	if [[ -e ${1} ]]; then
		#-- Copy the library using the current "install_name" as the path
		printStatus "  |- Copying Library '${1}' into app bundle"
		cp "${1}" "${LibPath}/."
	    
	    # Update the Executables link path to this library
	    oldPath="${1}"
	    libName=`basename ${oldPath}`
	    newPath="${InstallNameLib}/${libName}" 
	    #echo "   ${oldPath} \n   ${newPath}\n   ${2}"
	    install_name_tool -change ${oldPath} ${newPath} ${2}
	    
	    # Update the install_name of the library itself
	    install_name_tool -id ${newPath} "${LibPath}/${libName}"
	    
	    UpdateLibraryDependencies "${LibPath}/${libName}"
	fi
}

# -----------------------------------------------------------------------------
#  uses install_name_tool to correct all the DEPENDENCIES of an input file
#  $1 is a linked library
#  $2 is the executable in its final installed location
# -----------------------------------------------------------------------------
function UpdateExecutableDependencies()
{
  pattern=" \(*\)"            # everything between '(' and ')'
  oldPath="${1%$pattern}"
  # Filter out System Libraries or those located in /Libary/Frameworks
  isSystem=`expr  "${oldPath}" : '/System'`
  isUsrLib=`expr "${oldPath}" : '/usr/lib'`
  #isLibFrwk=`expr "${oldPath}" : '/Libraray/Frameworks'`
  isEmbeddedPathExe=`expr "${oldPath}" : '@executable_path/'`
  isEmbeddedPathLdr=`expr "${oldPath}" : '@loader_path/'`
  if [[ "$isSystem" = "0" \
    && "$isUsrLib" = "0" \
    && "$isEmbeddedPathExe" = "0" \
    && "$isEmbeddedPathLdr" = "0" ]]; then
      printStatus "- UpdateExecutableDependencies"
      #printStatus "      ${1}"
      #printStatus "      ${2}"
      libName=`basename ${oldPath}`
      frameworkName="${libName}.framework"
      isFramework=` echo ${oldPath} | grep "${frameworkName}"`
      if [[ "${#isFramework}" = "0" ]]; then
        UpdateDylibInstallName "${oldPath}" "${2}"
      else
        UpdateFrameworkInstallName "${oldPath}" "${2}"
      fi
   fi
}


# -----------------------------------------------------------------------------
#  Script really starts here
# -----------------------------------------------------------------------------
tmpFile="${TmpDir}/otool.out"
otool -L "${ApplicationExe}" > "${tmpFile}"

i=0
exec 9<"${tmpFile}"
while read -u 9 line
  do
  if [[ ${i} -gt 0 ]]; then
    UpdateExecutableDependencies "${line}" "${ApplicationExe}"     
  fi
  let i=i+1
done
exec 9<&-

