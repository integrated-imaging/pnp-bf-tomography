#! /bin/bash

scp OpenMBIR-v1.812-OSX.tar.gz mjackson@www.bluequartz.net:/var/www/www.openmbir.org/binaries/.
