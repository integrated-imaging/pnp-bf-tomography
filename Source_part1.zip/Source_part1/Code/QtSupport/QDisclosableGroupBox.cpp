/* ============================================================================
 * Copyright (c) 2012 Michael A. Jackson (BlueQuartz Software)
 * Copyright (c) 2012 Dr. Michael A. Groeber (US Air Force Research Laboratories)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of Michael A. Groeber, Michael A. Jackson, the US Air Force,
 * BlueQuartz Software nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior written
 * permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  This code was written under United States Air Force Contract number
 *                           FA8650-07-D-5800
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

#include "QDisclosableGroupBox.h"

#include <iostream>

#include <QtCore/QTimer>
#include <QtGui/QApplication>
#include <QtGui/QHBoxLayout>
#include <QtGui/QVBoxLayout>
#include <QtGui/QFormLayout>
#include <QtGui/QGridLayout>
#include <QtGui/QPainter>

#include <QtGui/QPushButton>
#include <QtGui/QFileDialog>
#include <QtGui/QMouseEvent>


#define PADDING 5
#define BORDER 2
#define IMAGE_WIDTH 17
#define IMAGE_HEIGHT 17

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
QDisclosableGroupBox::QDisclosableGroupBox(QWidget* parent) :
QGroupBox(parent)
{


//  m_DeleteRect.setX(PADDING + BORDER);
//  m_DeleteRect.setY(PADDING + BORDER);
//  m_DeleteRect.setWidth(IMAGE_WIDTH);
//  m_DeleteRect.setHeight(IMAGE_HEIGHT);

  connect(this, SIGNAL(toggled(bool)), this, SLOT(disclose(bool)));
//  updateWidgetStyle();
}

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
QDisclosableGroupBox::~QDisclosableGroupBox()
{
}



// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
void QDisclosableGroupBox::changeStyle()
{
}

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
void QDisclosableGroupBox::updateWidgetStyle()
{
  QString style;

  style.append("QGroupBox{\n");

  style.append("background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #FFFFFF, stop: 1 #DCDCDC);");
  style.append("background-image: url(:/DisclosableGroupBoxHeader.png);");
  style.append("background-position: top ;\n background-repeat: repeat-x;");

//  style.append("border-radius: 10px;");
  style.append("padding: 30 0 0 0px;");
#if defined(Q_WS_WIN)
  style.append("font: 85 italic 10pt \"Arial\";");
#elif defined(Q_WS_MAC)
  style.append("font: 85 italic 12pt \"Arial\";");
#else
  style.append("font: 85 italic 9pt \"Arial\";");
#endif
  style.append("font-weight: bold;");
  style.append("}\n");
  style.append(" QGroupBox::title {");
  style.append("    subcontrol-origin: padding;");
  style.append("    subcontrol-position: top left;");
  style.append("    padding: 5 5px;");
  style.append("    background-color: rgba(255, 255, 255, 0);");
  style.append(" }\n");
  style.append("QGroupBox::indicator {");
  style.append("    width: 17px;");
  style.append("    height: 17px;");
  style.append("}\n");
  style.append("\nQGroupBox::indicator:unchecked { image: url(:/bullet_triangle_grey.png);}");
  style.append("\nQGroupBox::indicator:unchecked:pressed { image: url(:/bullet_triangle_grey.png);}");
  style.append("\nQGroupBox::indicator:checked { image: url(:/bullet_triangle_grey_down.png);}");
  style.append("\nQGroupBox::indicator:checked:pressed { image: url(:/bullet_triangle_grey_down.png);}");

  setStyleSheet(style);
  //std::cout << style.toStdString() << std::endl;
}


// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
void QDisclosableGroupBox::setupGui()
{
  setCheckable(true);
 // updateWidgetStyle();
}

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
void QDisclosableGroupBox::disclose(bool on)
{

    if (on)
    {
        this->setMaximumHeight(260000);
    }
    else
    {
       this->setMaximumHeight(26);
    }

    QObjectList objs = children();
    foreach(QObject* obj, objs)
    {
      QWidget* w = qobject_cast<QWidget*>(obj);
      if(NULL != w)
      {
        if(on) w->show();
        else w->hide();
      }
    }


}

